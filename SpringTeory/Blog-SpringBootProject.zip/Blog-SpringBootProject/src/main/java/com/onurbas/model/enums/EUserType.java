package com.onurbas.model.enums;

public enum EUserType {
  USER,ADMIN
}
