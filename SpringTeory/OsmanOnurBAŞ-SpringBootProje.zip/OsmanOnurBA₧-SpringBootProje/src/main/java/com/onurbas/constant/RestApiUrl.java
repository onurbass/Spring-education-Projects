package com.onurbas.constant;

public class RestApiUrl {
  public final static String USER = "/users";
  public final static String POST = "/posts";
  public final static String CATEGORY = "/categories";

}
