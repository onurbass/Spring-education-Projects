package com.onurbas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootMonoliticRestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
