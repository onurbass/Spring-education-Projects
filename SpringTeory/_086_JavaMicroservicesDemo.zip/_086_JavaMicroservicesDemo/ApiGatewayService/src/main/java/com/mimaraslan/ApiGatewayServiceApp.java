package com.mimaraslan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class ApiGatewayServiceApp {
    public static void main(String[] args) {
        SpringApplication.run(ApiGatewayServiceApp.class);
    }
}