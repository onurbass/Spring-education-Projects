package com.tycase.onurbas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TyCaseApplicationTests {

  @Test
  void contextLoads() {
  }

}
