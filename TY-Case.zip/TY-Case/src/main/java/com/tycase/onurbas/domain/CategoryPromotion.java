package com.tycase.onurbas.domain;

import com.tycase.onurbas.domain.enums.ECategory;
import com.tycase.onurbas.domain.enums.EPromotion;
import lombok.*;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/*CategoryPromotion
		CategoryPromotion ID'si 5676 dur. Cart’ın üzerinde bulunan ve CategoryID'si 3003 olan
		itemlara %5 indirimli promotion tanımlanır, Cart'ın toplam tutarına uygulanır.*/

@EqualsAndHashCode(callSuper = true)
@Data
@NoArgsConstructor
@AllArgsConstructor

public class CategoryPromotion extends Promotion {

  @Builder.Default
  private int id = EPromotion.CATEGORY_PROMOTION.getId();

  private static final double DISCOUNT_RATE = 0.05;



  @Override
  public double calculateDiscount(Double totalPrice) {
	return 0;
  }
}
