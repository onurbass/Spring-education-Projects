package com.tycase.onurbas.domain;

import com.tycase.onurbas.domain.enums.ECategory;
import lombok.*;

//DigitalItem
//		DigitalItem olan bir cart'a sadece digital item eklenebilir. Digital item; steam card, bağış kartı
//		vb. gibi itemlardir. DigitalItem'ın maksimum eklenme adedi 5'tir. d. CategoryID'si 7889 olan
//		itemlar DigitalItem olarak tanımlanır. Bu CategoryID ile başka türden bir Item tanımlanamaz.

@EqualsAndHashCode(callSuper = true)
@Data
public class DigitalItem extends Item {


  public DigitalItem() {
	this.categoryId = ECategory.DIGITAL_ITEM.getId();
  }
}
