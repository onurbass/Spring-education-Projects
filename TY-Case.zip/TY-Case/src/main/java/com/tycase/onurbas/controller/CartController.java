package com.tycase.onurbas.controller;

import com.tycase.onurbas.domain.Cart;
import com.tycase.onurbas.domain.Item;
import com.tycase.onurbas.service.CartService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/v1/cart")
@RequiredArgsConstructor
public class CartController {
  private final CartService cartService;


  @PostMapping
  public ResponseEntity<Void> addItemToCart(@RequestBody Item item) {
	cartService.addItemToCart(item);

	return ResponseEntity.ok().build();

  }
  @GetMapping("/")
  public ResponseEntity<Cart> getCart() {
	return ResponseEntity.ok(cartService.getCart());

  }




}
