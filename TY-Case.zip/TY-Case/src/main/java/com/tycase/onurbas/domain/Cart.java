package com.tycase.onurbas.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.List;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
public class Cart {
  private static final int MAX_UNIQUE_ITEM_COUNT = 10;
  private static final int MAX_TOTAL_ITEM_COUNT = 30;
  private static final double MAX_TOTAL_PRICE = 500000;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private int id;
  private int userId;
  private int cartTotalQuantity;
  private int cartUniqueItemCount;
  private double cartTotalPrice;
  private double cartTotalDiscountedPrice;

@OneToMany(cascade = CascadeType.ALL)
  private List<Item> items;

  public void addItem(Item item) {

    this.items.add((item));

  }

}
