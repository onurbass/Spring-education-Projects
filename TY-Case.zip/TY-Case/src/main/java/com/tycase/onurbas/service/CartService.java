package com.tycase.onurbas.service;


import com.tycase.onurbas.domain.Cart;
import com.tycase.onurbas.repository.CartRepository;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;



@Service
@RequiredArgsConstructor
public class CartService {
  private final CartRepository cartRepository;

  public String save (Cart cart){
	cartRepository.save(cart);
	return "başarılı";
  }







}
