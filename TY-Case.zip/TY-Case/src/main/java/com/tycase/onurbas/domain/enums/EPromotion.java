package com.tycase.onurbas.domain.enums;

public enum EPromotion {
  SAME_SELLER_PROMOTION(9909),
  CATEGORY_PROMOTION(5676),
  TOTAL_PRICE_PROMOTION(1232),
  ;
  private int id;

  EPromotion(int id) {
	this.id = id;
  }

  public int getId() {
	return id;
  }
}
