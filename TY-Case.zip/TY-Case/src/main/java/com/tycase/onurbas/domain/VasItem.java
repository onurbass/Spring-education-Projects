package com.tycase.onurbas.domain;

import com.tycase.onurbas.domain.enums.ECategory;
import com.tycase.onurbas.domain.enums.ESeller;
import lombok.*;

//VasItem
//		Value Added Service item sigorta, montaj gibi hizmetleri ifade eder. Bu ürünler fiziksel bir
//		ürünü değil belli bir ürüne bağlı hizmeti ifade eder ve tek başlarına bir anlamı yoktur.
//		Bu nedenle sadece Mobilya (CategoryID: 1001) ve Elektronik(CategoryID: 3004)
//		kategorisindeki default itemlara alt item olarak eklenebilir. Bir DefaultItem'a maksimum 3
//		adet VASItem eklenebilir. VasItem'in CategoryID'si 3242'dir. VasItem'ların satıcı ID'si
//		5003'tur. Satıcı ID'si 5003 olmayan VasItemlar tanımlanamaz. Satıcı ID'si 5003 olan baska
//		türde bir Item türü yoktur.
@EqualsAndHashCode(callSuper = true)
@Data

public class VasItem extends Item {

  private static final int MAX_VAS_ITEM_COUNT = 3;

  public VasItem() {
	this.categoryId = ECategory.VAS_ITEM.getId();
	this.sellerId = ESeller.VAS_SELLER.getId();
  }
}
