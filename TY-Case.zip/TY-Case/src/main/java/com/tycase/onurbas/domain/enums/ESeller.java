package com.tycase.onurbas.domain.enums;

public enum ESeller {

  VAS_SELLER(5003);
  private int id;

  ESeller(int id) {
	this.id = id;
  }

  public int getId() {
	return id;
  }
}
