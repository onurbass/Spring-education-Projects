package com.tycase.onurbas.domain.enums;

public enum ECategory {

  FURNITURE(1001),
  ELECTRONIC(3004),
  VAS_ITEM(3242),
  DIGITAL_ITEM(7889),
  PRIVILEGED_ITEM(3003);

  private int id;

  ECategory(int id) {
	this.id = id;
  }

  public int getId() {
	return id;
  }
}