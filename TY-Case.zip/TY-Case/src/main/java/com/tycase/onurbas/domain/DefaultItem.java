package com.tycase.onurbas.domain;

import lombok.*;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data

public abstract class DefaultItem extends Item{

  private List<VasItem> vasItems;
}
