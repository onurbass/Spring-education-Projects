package com.tycase.onurbas.domain;

import lombok.Data;

@Data
public  class Item {
  protected int itemId;
  protected int categoryId;
  protected int sellerId;
  protected double price;
  protected int quantity;
}
