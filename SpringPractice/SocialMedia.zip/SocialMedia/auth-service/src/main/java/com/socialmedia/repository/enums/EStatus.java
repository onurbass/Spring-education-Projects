package com.socialmedia.repository.enums;

public enum EStatus {

    ACTIVE, DELETED, PENDING, BANNED, INACTIVE
}
