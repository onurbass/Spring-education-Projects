package com.socialmedia.repository.enums;

public enum ERole {

    USER,ROLE
}
